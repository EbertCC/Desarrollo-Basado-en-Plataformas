<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bd_formulario";

$BD = new mysqli($servername, $username, $password, $dbname);

if ($BD->connect_error) {
    die("Conexión fallida: " . $BD->connect_error);
}

$sql = "SELECT * FROM Usuarios";
$result = $BD->query($sql);

if ($result->num_rows > 0) {
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Pagina web dinamica</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f9f9f9;
            }
            .container {
                width: 100%;
                max-width: 900px;
                margin: 30px auto;
                background-color: #fff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            }
            h1, h2 {
                color: #333;
            }
            h3 {
                color: #666;
                font-size: 18px;
            }
            p {
                color: #555;
                font-size: 16px;
                line-height: 1.6;
            }
            .section {
                margin-bottom: 30px;
            }
            .aptitudes, .habilidades {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }
            .aptitudes li, .habilidades li {
                background-color: #e0f7fa;
                padding: 8px 15px;
                border-radius: 25px;
                list-style: none;
                color: #00796b;
            }
        </style>
    </head>
    <body>
    <div class="container">
        <h1>Perfiles</h1>
        <?php

        while ($row = $result->fetch_assoc()) {
            echo "<div class='section'>";
            echo "<h2>" . $row['nombre_apellidos'] . "</h2>";

            echo "<h3>Experiencia Laboral</h3>";
            echo "<p>" . $row['experiencia_laboral'] . "</p>";

            echo "<h3>Formación</h3>";
            echo "<p>" . $row['formacion'] . "</p>";

            echo "<h3>Nivel de Inglés</h3>";
            echo "<p>" . $row['nivel_ingles'] . "</p>";

            echo "<h3>Aptitudes</h3>";
            echo "<ul class='aptitudes'>";
            echo "<li>" . $row['aptitudes'] . "</li>";
            echo "</ul>";

            echo "<h3>Habilidades</h3>";
            echo "<ul class='habilidades'>";
            $habilidades = explode(", ", $row['habilidades']);
            foreach ($habilidades as $habilidad) {
                echo "<li>$habilidad</li>";
            }
            echo "</ul>";
            echo "</div><hr>";
        }
        ?>
    </div>
    </body>
    </html>
    <?php
} else {
    echo "<h3>No se encontraron registros en la base de datos.</h3>";
}

$BD->close();
?>
