<?php

$servername = "localhost";
$username = "root";  
$password = "";     
$dbname = "bd_formulario";

$BD = new mysqli($servername, $username, $password, $dbname);

if ($BD->connect_error) {
    die("Conexión fallida: " . $BD->connect_error);
}

$nombre_apellidos = $_POST['nombre_apellidos'];
$experiencia_laboral = $_POST['experiencia_laboral'];
$formacion = $_POST['formacion'];
$nivel_ingles = $_POST['nivel_ingles'];
$aptitudes = $_POST['aptitudes'];
$habilidades = implode(", ", $_POST['habilidades']);

$sql = "INSERT INTO Usuarios (nombre_apellidos, experiencia_laboral, formacion, nivel_ingles, aptitudes, habilidades) 
        VALUES ('$nombre_apellidos', '$experiencia_laboral', '$formacion', '$nivel_ingles', '$aptitudes', '$habilidades')";

if ($BD->query($sql) === TRUE) {
    echo "<h3>Datos guardados correctamente.</h3>";
} else {
    echo "Error: " . $sql . "<br>" . $BD->error;
}

$BD->close();
?>
