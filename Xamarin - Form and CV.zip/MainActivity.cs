using Android.App;
using Android.OS;
using Android.Widget;
using Android.Content;
using AndroidApp3;

namespace AndroidApp1
{
    [Activity(Label = "@string/app_name", MainLauncher = true)]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle? savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Establece el dise�o principal
            SetContentView(Resource.Layout.activity_main);

            // Conectar los elementos del formulario
            EditText nameField = FindViewById<EditText>(Resource.Id.input_name);
            EditText ageField = FindViewById<EditText>(Resource.Id.input_age);
            EditText occupationField = FindViewById<EditText>(Resource.Id.input_occupation);
            EditText descriptionField = FindViewById<EditText>(Resource.Id.input_description);
            Button submitButton = FindViewById<Button>(Resource.Id.btn_submit);

            // Configurar la acci�n del bot�n
            submitButton.Click += (sender, e) =>
            {
                // Obtener los valores ingresados
                string name = nameField.Text;
                string age = ageField.Text;
                string occupation = occupationField.Text;
                string description = descriptionField.Text;

                // Crear una intenci�n para abrir la nueva actividad
                Intent intent = new Intent(this, typeof(DisplayActivity));
                intent.PutExtra("name", name);
                intent.PutExtra("age", age);
                intent.PutExtra("occupation", occupation);
                intent.PutExtra("description", description);

                // Iniciar la nueva actividad
                StartActivity(intent);
            };
        }
    }
}
