/*
namespace AndroidApp3;

[Activity(Label = "DisplayActivity")]
public class DisplayActivity : Activity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);

        // Create your application here

    }

}
*/


namespace AndroidApp3;

[Activity(Label = "DisplayActivity")]
public class DisplayActivity : Activity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);

        // Establece el dise�o de esta actividad
        SetContentView(Resource.Layout.activity_display);

        // Recupera los datos enviados desde MainAc tivity
        string name = Intent.GetStringExtra("name") ?? "No se ingres� el nombre";
        string age = Intent.GetStringExtra("age") ?? "No se ingres� la edad";
        string occupation = Intent.GetStringExtra("occupation") ?? "No se ingres� la ocupaci�n";
        string description = Intent.GetStringExtra("description") ?? "No se ingres� la descripci�n";

        // Conecta el TextView del dise�o
        TextView textView = FindViewById<TextView>(Resource.Id.text_display);
        textView.Text = $"Nombre: {name}\nEdad: {age}\nOcupaci�n: {occupation}\nDescripci�n: {description}";
    }
}
