﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;


namespace App4
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnGuardarClicked(object sender, EventArgs e)
        {
            // Obtener los datos ingresados
            string nombre = nombreEntry.Text;
            string experiencia = experienciaEditor.Text;
            string formacion = formacionEditor.Text;

            string nivelIngles = basicoRadio.IsChecked ? "Básico" :
                                 intermedioRadio.IsChecked ? "Intermedio" :
                                 avanzadoRadio.IsChecked ? "Avanzado" : "Fluido";

            string aptitud = aptitudesPicker.SelectedItem?.ToString();

            string habilidades = "";
            if (comunicacionCheck.IsChecked) habilidades += "Comunicación, ";
            if (organizacionCheck.IsChecked) habilidades += "Organización, ";
            if (creatividadCheck.IsChecked) habilidades += "Creatividad, ";
            if (adaptabilidadCheck.IsChecked) habilidades += "Adaptabilidad";

            habilidades = string.IsNullOrWhiteSpace(habilidades) ? "Ninguna" : habilidades.TrimEnd(',', ' ');

            // Navegar a la nueva página para mostrar los datos
            await Navigation.PushAsync(new DatosPage(nombre, experiencia, formacion, nivelIngles, aptitud, habilidades));
        }
    }
}
