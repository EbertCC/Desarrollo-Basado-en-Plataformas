﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
/*
namespace App4
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DatosPage : ContentPage
    {
        public DatosPage()
        {
            InitializeComponent();
        }
    }
}
*/


namespace App4
{
    public partial class DatosPage : ContentPage
    {
        public DatosPage(string nombre, string experiencia, string formacion, string nivelIngles, string aptitud, string habilidades)
        {
            InitializeComponent();

            // Asignar los valores a los Labels
            nombreLabel.Text = nombre;
            experienciaLabel.Text = experiencia;
            formacionLabel.Text = formacion;
            nivelInglesLabel.Text = nivelIngles;
            aptitudesLabel.Text = aptitud;
            habilidadesLabel.Text = habilidades;
        }
    }
}
