<?php
//conexion BD
$servername = "localhost";
$username = "root";  
$password = "";      
$dbname = "UsuariosDB";

$BD = new mysqli($servername, $username, $password, $dbname);

if ($BD->connect_error) {
    die("Conexión fallida: " . $BD->connect_error);
}

//recibir los input del captura.html
$nombre_apellidos = $_POST['nombre_apellidos'];
$fecha_nacimiento = $_POST['fecha_nacimiento'];
$ocupacion = $_POST['ocupacion'];
$contacto = $_POST['contacto'];
$nacionalidad = $_POST['nacionalidad'];
$nivel_ingles = $_POST['nivel_ingles'];
$lenguajes_programacion = implode(", ", $_POST['lenguajes_programacion']);
$aptitudes = $_POST['aptitudes'];
$habilidades = implode(", ", $_POST['habilidades']);
$perfil = $_POST['perfil'];

//guardar los inputs a mi BD
$sql = "INSERT INTO Usuarios (nombre_apellidos, fecha_nacimiento, ocupacion, contacto, nacionalidad, nivel_ingles, lenguajes_programacion, aptitudes, habilidades, perfil) 
        VALUES ('$nombre_apellidos', '$fecha_nacimiento', '$ocupacion', '$contacto', '$nacionalidad', '$nivel_ingles', '$lenguajes_programacion', '$aptitudes', '$habilidades', '$perfil')";

if ($BD->query($sql) === TRUE) {
    echo "<h3>Los datos del usuario $nombre_apellidos fueron guardados correctamente.</h3>";
} else {
    echo "Error: " . $sql . "<br>" . $BD->error;
}

//cierro conexion
$BD->close();
?>
