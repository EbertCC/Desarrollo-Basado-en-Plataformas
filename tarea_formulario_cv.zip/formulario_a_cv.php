<?php
//conexión a BD
$servername = "localhost";
$username = "root";  
$password = "";      
$dbname = "UsuariosDB";

$BD = new mysqli($servername, $username, $password, $dbname);

if ($BD->connect_error) {
    die("Conexión fallida: " . $BD->connect_error);
}

// obtener todos los usuarios de BD
$sql = "SELECT * FROM Usuarios ORDER BY id DESC";
$result = $BD->query($sql);

if ($result->num_rows > 0) {
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Lista de Clientes Ingresados</title>
        <link rel="stylesheet" href="styles.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    </head>
    <body>
    <div class="container">
        <h1>Lista de Usuarios Ingresados</h1>
        <?php
        //Recorrer toda la tabla de BD y guardar valores
        while ($row = $result->fetch_assoc()) {
            $nombre_apellidos = $row['nombre_apellidos'];
            $fecha_nacimiento = $row['fecha_nacimiento'];
            $ocupacion = $row['ocupacion'];
            $contacto = $row['contacto'];
            $nacionalidad = $row['nacionalidad'];
            $nivel_ingles = $row['nivel_ingles'];
            $lenguajes_programacion = $row['lenguajes_programacion'];
            $aptitudes = $row['aptitudes'];
            $habilidades = $row['habilidades'];
            $perfil = $row['perfil'];

            ?>
            <div class="header">
                <div class="header-img">
                    <img src="profile.png" alt="Foto de <?php echo $nombre_apellidos; ?>">
                </div>
                <div class="header-info">
                    <br>
                    <h2><?php echo $nombre_apellidos; ?></h2>
                    <p><?php echo $ocupacion; ?></p>
                </div>
            </div>

            <div id="parent">
                <div id="narrow">
                    <div class="contact">
                        <h2>CONTACTO</h2>
                        <p><i class="fas fa-phone-alt"></i> <?php echo $contacto; ?></p>
                        <p><i class="fas fa-map-marker-alt"></i> <?php echo $nacionalidad; ?></p>
                    </div>

                    <div class="idiomas">
                        <h2>NIVEL DE INGLÉS</h2>
                        <p><?php echo $nivel_ingles; ?></p>
                    </div>

                    <div class="aptitudes">
                        <h2>APTITUDES</h2>
                        <ul>
                            <li><?php echo $aptitudes; ?></li>
                        </ul>
                    </div>

                    <div class="habilidades">
                        <h2>HABILIDADES</h2>
                        <ul>
                            <li><?php echo $habilidades; ?></li>
                        </ul>
                    </div>
                </div>

                <div id="wide">
                    <div class="profile">
                        <h2>PERFIL</h2>
                        <p><?php echo $perfil; ?></p>
                    </div>
                </div>
            </div>

            <hr> 

            <?php
        } 
        ?>
    </div>
    </body>
    </html>

    <?php
} else { // si no se encontraron 
    echo "<h3>No se encontraron registros.</h3>";
}
//ciero la BD
$BD->close();
?>
